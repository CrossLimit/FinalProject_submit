import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-forget',
  templateUrl: './login-forget.component.html',
  styleUrls: ['./login-forget.component.css']
})
export class LoginForgetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
