export class Register {

    email: string;
    password: string;
    repeatpassword:string;
}