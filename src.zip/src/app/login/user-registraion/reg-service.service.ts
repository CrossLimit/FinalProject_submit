// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { Register } from './Register';

// @Injectable({
//   providedIn: 'root'
// })
// export class RegServiceService {

//     constructor(private registerUser:HttpClient) { }


//   f2(user:Register):Observable<any>
//   {
//     const x ="http://localhost:9000/insert";

//     return this.registerUser.post(x,user);
//   }
// }
