import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainerRegComponent } from './trainer-reg.component';

describe('TrainerRegComponent', () => {
  let component: TrainerRegComponent;
  let fixture: ComponentFixture<TrainerRegComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrainerRegComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainerRegComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
