import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainer-reg',
  templateUrl: './trainer-reg.component.html',
  styleUrls: ['./trainer-reg.component.css']
})
export class TrainerRegComponent implements OnInit {

  constructor() { }


  
  ngOnInit() {
  }

}
