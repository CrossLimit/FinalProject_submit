import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PremiumTrainerComponent } from './premium-trainer.component';

describe('PremiumTrainerComponent', () => {
  let component: PremiumTrainerComponent;
  let fixture: ComponentFixture<PremiumTrainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PremiumTrainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PremiumTrainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
