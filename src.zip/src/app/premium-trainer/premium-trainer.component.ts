import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-premium-trainer',
  templateUrl: './premium-trainer.component.html',
  styleUrls: ['./premium-trainer.component.css']
})
export class PremiumTrainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
