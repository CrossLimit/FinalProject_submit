import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simple-user',
  templateUrl: './simple-user.component.html',
  styleUrls: ['./simple-user.component.css']
})
export class SimpleUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
