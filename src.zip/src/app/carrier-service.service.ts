import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Register } from './login/user-registraion/Register';
import { LoginTrainer, Question } from './CarrierModel';
@Injectable({
  providedIn: 'root'
})
export class CarrierServiceService {

  constructor(private http:HttpClient) { }


  f2(user:Register):Observable<any>
  {
    const x ="http://localhost:9000/insert";
    return this.http.post<String>(x,user);
  }

// for the Test login by the Tranainer



  insertTrainerTest(trainer:LoginTrainer){
    const x ="http://localhost:9000/insertTest";
    return this.http.post<String>(x,trainer);
  }

//INserting  the Question from the Trainer Module  
quizQuestion(qAdmin:Question){
  const x ="http://localhost:9000/insertQuestion";
  return this.http.post<any>(x,qAdmin);
}

//validate Users
passValidate(email:String):Observable<any> {
  let x = "http://localhost:9000/getP?email="+email;
  return this.http.get(x);
}

fetchTest(subject:string):Observable<any> {
  let x = "http://localhost:9000/getTest?subject="+subject;
  return this.http.get(x);
}

fetchQuestion(test:string):Observable<any> {
  let x = "http://localhost:9000/getques?test="+test;
  return this.http.get(x);
}


}



