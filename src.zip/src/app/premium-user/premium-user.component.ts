import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-premium-user',
  templateUrl: './premium-user.component.html',
  styleUrls: ['./premium-user.component.css']
})
export class PremiumUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
