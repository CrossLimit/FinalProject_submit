import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FeatureComponent } from './feature/feature.component';
import { CoursesComponent } from './courses/courses.component';
import { LoginComponent } from './login/login.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { PremiumUserComponent } from './premium-user/premium-user.component';
import { PremiumTrainerComponent } from './premium-trainer/premium-trainer.component';
import { SimpleUserComponent } from './simple-user/simple-user.component';
import { LoginStudentComponent } from './login/login-student/login-student.component';
import { LoginTrainerComponent } from './login/login-trainer/login-trainer.component';
import { LoginForgetComponent } from './login/login-forget/login-forget.component';
import { UserRegistraionComponent } from './login/user-registraion/user-registraion.component';
import { TrainerRegComponent } from './login/trainer-reg/trainer-reg.component';
import { RegSuccessComponent } from './login/reg-success/reg-success.component';
import { HomeContentComponent } from './home-content/home-content.component';
import { FormsModule} from '@angular/forms';
import { LoginHeaderComponent } from './login/login-header/login-header.component';
import { LogoutSuccessComponent } from './login/logout-success/logout-success.component';
import { RetrieveTestComponent } from './login/retrieve-test/retrieve-test.component';
import { PostTestComponent } from './login/post-test/post-test.component';
import { ResultComponent } from './login/result/result.component';
import { QueryComponent } from './login/query/query.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HttpClientModule } from '@angular/common/http';
import { CarrierServiceService } from './carrier-service.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {MatSelectModule} from '@angular/material/select';
//import { RegServiceService } from './login/user-registraion/reg-service.service';
//import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    FeatureComponent,
    CoursesComponent,
    LoginComponent,
    AboutUsComponent,
    ContactUsComponent,
    PremiumUserComponent,
    PremiumTrainerComponent,
    SimpleUserComponent,
    LoginStudentComponent,
    LoginTrainerComponent,
    LoginForgetComponent,
    UserRegistraionComponent,
    TrainerRegComponent,
    RegSuccessComponent,
    HomeContentComponent,
    LoginHeaderComponent,
    LogoutSuccessComponent,
    RetrieveTestComponent,
    PostTestComponent,
    ResultComponent,
    QueryComponent,
    PageNotFoundComponent,
    
   
    
    
    
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    MatSelectModule,
    BrowserAnimationsModule,
    
   //ReactiveFormsModule
  ],
  providers: [CarrierServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
