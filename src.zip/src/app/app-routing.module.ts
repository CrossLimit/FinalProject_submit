import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FeatureComponent } from './feature/feature.component';
import { CoursesComponent } from './courses/courses.component';
import { LoginComponent } from './login/login.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { PremiumUserComponent } from './premium-user/premium-user.component';
import { PremiumTrainerComponent } from './premium-trainer/premium-trainer.component';
import { SimpleUserComponent } from './simple-user/simple-user.component';

import { LoginStudentComponent } from './login/login-student/login-student.component';
import { LoginTrainerComponent } from './login/login-trainer/login-trainer.component';
import { LoginForgetComponent } from './login/login-forget/login-forget.component';

import { UserRegistraionComponent } from './login/user-registraion/user-registraion.component';
import { TrainerRegComponent } from './login/trainer-reg/trainer-reg.component';
import { RegSuccessComponent } from './login/reg-success/reg-success.component';
import { HomeContentComponent } from './home-content/home-content.component';

import { LogoutSuccessComponent } from './login/logout-success/logout-success.component';
import { PostTestComponent } from './login/post-test/post-test.component';
import { RetrieveTestComponent } from './login/retrieve-test/retrieve-test.component';
import { ResultComponent } from './login/result/result.component';
import { QueryComponent } from './login/query/query.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const routes: Routes = [
  {path:'',component:HomeContentComponent},
  {path:'HomeContent',component:HomeContentComponent},
  {path:'ContactUs',component: ContactUsComponent},
  {path:'AboutUs',component: AboutUsComponent},
  {path:'Login',component: LoginComponent,
  children: 
    [
        
        {path:'LogoutSuccess',component:LogoutSuccessComponent},
        {path:'LoginForget', component:LoginForgetComponent},      
        {path:'LoginStudent',component:LoginStudentComponent},
        {path:'LoginTrainer',component:LoginTrainerComponent},
        {path:'LoginForget',component:LoginForgetComponent},
        {path:'UserRegistration', component:UserRegistraionComponent},
        {path:'RegSuccess',component:RegSuccessComponent},
        {path:'PutTest', component:PostTestComponent},
        {path:'RetrieveTest',component:RetrieveTestComponent},
        {path:'Result',component:ResultComponent},
        {path:'Query',component:QueryComponent},
       
  ]},
  {path:'Query',component:QueryComponent},
  {path:'Feature', component: FeatureComponent},
  {path:'Courses', component: CoursesComponent},
  {path:'PremiumUser', component: PremiumUserComponent},
  {path:'PremiumTrainer', component:PremiumTrainerComponent},
  {path:'SimpleUser', component: SimpleUserComponent},
  { path: '**', component: PageNotFoundComponent }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
