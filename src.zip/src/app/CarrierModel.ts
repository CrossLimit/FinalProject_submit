export class LoginTrainer{
 	 subjects: String;
  
    constructor(){};
    subject:string;
    test:string;

}
export class Question{
//   [x: string]: number;
    questionno:string;
    questions:string;
	options1 :string;
	options2 :string;
	options3 :string;
	options4 :string;
	optionscorrect:string;
	test:string;
}
export class Login{
	email:string;
	password:string;
}