package exam.hello;

import java.io.FileWriter;
import java.io.IOException;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			System.setSecurityManager(new SecurityManager());
			FileWriter fw =new FileWriter("a.txt");
			fw.close();
			System.out.println("File created");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
