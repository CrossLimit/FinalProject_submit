package exam.hello;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class B {
	
	private C obj1;
	
	
	@Autowired
	public void setObj1(C obj1) {
		System.out.println("Service : repository DAO  wired to service ");
		this.obj1 = obj1;
	}




	public B()
	{
		
		//System.out.println("B object created");
	}




	public String insertFunction(Register n) {
		
		if(obj1.findById(n.getEmail()) != null)
		{System.out.println("hello we are correct");
				obj1.save(n); //change of failing is almost zero.
		}
		else
				System.out.println("update failed");
		return "great";
	}




	

}
