package exam.hello;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@CrossOrigin(origins = "*")
@RestController
public class A {
	
	private B obj1;
	
	public A()
	{
		////System.out.println("A object created");
		
	}
	
	
	@Autowired
	public void setObj1(B obj1) {
		System.out.println("Controller : service is wired with Controller ");
		this.obj1 = obj1;
	}

	
	@PostMapping("/upd")
	public String f2(@RequestBody Register n)//assume single select
	{
		RestTemplate x=new RestTemplate();
		
		String m =obj1.insertFunction(n);
		return m;
		
	}
	
}
