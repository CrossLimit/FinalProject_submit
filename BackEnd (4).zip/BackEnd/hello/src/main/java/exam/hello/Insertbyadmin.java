package exam.hello;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Insertbyadmin{
	
	@Id
	private String test;
	private String subject;	
	
	public String getSubject() {
		return subject;
	}
	public String getTest() {
		return test;
	}
	
	
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public void setTest(String test) {
		this.test = test;
	}
	public Insertbyadmin(String test,String subject) {
		
		this.test = test;
		this.subject = subject;
		
	}
	public Insertbyadmin() {
		System.out.println("Insert table is getting data");
	}
	
	
}
	
	
	
	
	
	