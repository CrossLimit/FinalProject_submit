package exam.hello;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceLayer {
	@Autowired
	private RegisterJpa registerJpa;	
//	@Autowired
//	public void setObj1(C obj1) {
//		System.out.println("Service : repository DAO  wired to service ");
//		this.obj1 = obj1;
//	}
	@Autowired
	private InsertTestJpa insertTestJpa;	
	
//	
//	@Autowired
//	public void setInsertTestJpa(InsertTestJpa insertTestJpa) {
//		System.out.println("Service : repository DAO  wired to service ");
//		this.insertTestJpa = insertTestJpa;
//	}
	@Autowired
	private QuestionJpa questionJpa;
	
	public ServiceLayer()
	{		
		System.out.println("ServiceLayer object created");
	}
	
	
	
	public String insertFunction(Register n) {
		if(registerJpa.existsById(n.getEmail())==false)
		{  
			registerJpa.save(n); //change of failing is almost zero.
				System.out.println("Insert successfull");
				return "great";
		}
		else
		{
			System.out.println("update failed");
				return "not Great";
		}
	}
	
	
	
	public String testTo(Insertbyadmin test) {
		String returnText;
		
	if(insertTestJpa.existsById(test.getTest())==false)
		{  
			insertTestJpa.save(test);
			System.out.println("Test Insert successfull");
			
			 returnText= "Submitted SuccessFully";			
		}
		else {	
		 returnText="Already Existed Test";
		}
	return returnText;		
	}
	
	
	
	
	public int questionToSave(Question n) {
		if(questionJpa.existsById(n.getQuestionno())==false)
		{  
				questionJpa.save(n); //change of failing is almost zero.
				System.out.println("Insert successfull");
				return 1;
		}
		else
		{
			System.out.println("update failed");
			return 0;
		}
	}



	public String getPassword(String email) {
		String s= registerJpa.getP(email);		
		 return s;
	}



	public List<Question> getQns(String testno) {
		List<Question> v= questionJpa.getTest(testno);
		// TODO Auto-generated method stub
		return v;
	}



	public List<String> getTestno(String subject) {
		
		List<String> v=insertTestJpa.selectTest(subject);		
		
		return v;
	}



	
	
}
