package exam.hello;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Question {
	@Id
	private String questionno;
	private String questions;
	private String options1;
	private String options2;
	private String options3;
	private String options4;
	private String optionscorrect;
	private String test;
	public Question(String questionno, String questions, String options1, String options2, String options3,
				String options4, String optionscorrect, String test) {
		this.questionno = questionno;
		this.questions = questions;
		this.options1 = options1;
		this.options2 = options2;
		this.options3 = options3;
		this.options4 = options4;
		this.optionscorrect = optionscorrect;
		this.test = test;
	}
	public void setQuestionNo(String questionno) {
		this.questionno = questionno;
	}
	public void setQuestions(String questions) {
		this.questions = questions;
	}
	public void setOptions1(String options1) {
		this.options1 = options1;
	}
	public void setOptions2(String options2) {
		this.options2 = options2;
	}
	public void setOptions3(String options3) {
		this.options3 = options3;
	}
	public void setOptions4(String options4) {
		this.options4 = options4;
	}
	public void setOptionscorrect(String optionscorrect) {
		this.optionscorrect = optionscorrect;
	}
	public void setTest(String test) {
		this.test = test;
	}
	public String getQuestionno() {
		return questionno;
	}
	public String getQuestions() {
		return questions;
	}
	public String getOptions1() {
		return options1;
	}
	public Question() {
		System.out.println("Questions are Inserted");
	}
	public String getOptions2() {
		return options2;
	}
	public String getOptions3() {
		return options3;
	}
	public String getOptions4() {
		return options4;
	}
	public String getOptionscorrect() {
		return optionscorrect;
	}
	public String getTest() {
		return test;
	}
}
