package exam.hello;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface QuestionJpa extends JpaRepository<Question, String>{

	@Query(value="Select * from Question where test=:testno",nativeQuery=true)
	List<Question> getTest(String testno);


		
}