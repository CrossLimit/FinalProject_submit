package exam.hello;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.CrossOrigin;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestParam;
	import org.springframework.web.bind.annotation.RestController;
	import org.springframework.web.client.RestTemplate;


@CrossOrigin(origins = "*")
@RestController
public class Controller1 {
	
	private ServiceLayer service;	
	public Controller1()
	{	
		
	}
	
	
	@Autowired
	public void setService(ServiceLayer service) {
		this.service = service;
	}

	
	@PostMapping("/insert")
	public String f2(@RequestBody Register n)
	{
		String m =service.insertFunction(n);
		return m;
	}
	
	@PostMapping("/insertTest")
	public String insertTest(@RequestBody Insertbyadmin data )
	{
		String m =service.testTo(data);
		System.out.println(m);
		return m;
	}
	
	@PostMapping("/insertQuestion")
	public int TestQuestion(@RequestBody Question data )
	{
		int m =service.questionToSave(data);
		System.out.println(m);
		return m;
	}
	
	@GetMapping("/getP")
	public String getPass(@RequestParam("email") String email )
	{
		
		String  m =service.getPassword(email);
		System.out.println("from DAO  "+m);
		
		return m;
		
	}
	
	@GetMapping("/getTest")
	public List<String> getTest(@RequestParam("subject") String subject )
	{
		List<String> m=service.getTestno(subject);
		System.out.println("from DAO   " +m);
		https://material.angular.io/cdk/categories
		return m;
		
	}
	
	
	
	@GetMapping("/getques")
	public List<Question> getQues(@RequestParam("test") String testno )
	{
		List<Question> m =service.getQns(testno);
		return m;
		
	}
	
}
