package exam.hello;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface RegisterJpa extends JpaRepository<Register, String>{
	
	//Mobile is entity class, Integer is primary key
	// hibernate will never work until you use concept called Primary key.
	
	@Query("SELECT password FROM Register u WHERE u.email=:e")
	String getP(String e);

	
	
	
	 /*
	  //you dont need to write this if you got something else please go ahead and use it.
	  
	  //import delete should work and how it works it is left to you.
	  @Modifying
    @Query("delete from User u where u.firstName = ?1")
    void deleteUsersByFirstName(String firstName);

	  
	  
	 */
	

}
