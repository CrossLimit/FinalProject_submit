package exam.hello;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Register {
	
	@Id
	private String email;
	private String password;
	private String repeatpassword;
		
	public Register() {
	
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setRepeatpassword(String repeatpassword) {
		this.repeatpassword = repeatpassword;
	}
	public String getEmail() {
		return email;
	}
	public String getPassword() {
		return password;
	}
	public String getRepeatpassword() {
		return repeatpassword;
	}
	public Register(String email, String password, String repeatpassword) {

		this.email = email;
		this.password = password;
		this.repeatpassword = repeatpassword;
	}
	
	
}




	
	